package edu.westga.cs1302.airport.viewmodel;

import edu.westga.cs1302.airport.model.FlightDetails;
import edu.westga.cs1302.airport.model.FlightKey;
import edu.westga.cs1302.airport.model.FlightType;
import edu.westga.cs1302.airport.model.Flights;
import edu.westga.cs1302.airport.model.Terminal;
import javafx.beans.property.ListProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;

/**
 * The Class AirportViewModel.
 * 
 * @author CS1302
 */
public class AirportViewModel {

	private final StringProperty airlineProperty;
	private final StringProperty aircraftProperty;
	private final ObjectProperty<FlightType> typeProperty;
	private final ObjectProperty<Terminal> terminalProperty;
	private final ListProperty<Terminal> terminalsProperty;
	private final ListProperty<FlightType> typesProperty;
	private final ListProperty<FlightKey> flightsListProperty;

	private Flights flights;

	/**
	 * Instantiates a new AirportViewModel.
	 */
	public AirportViewModel() {
		this.terminalsProperty = new SimpleListProperty<Terminal>(FXCollections.observableArrayList(Terminal.values()));
		this.typesProperty = new SimpleListProperty<FlightType>(FXCollections.observableArrayList(FlightType.values()));
		this.airlineProperty = new SimpleStringProperty();
		this.aircraftProperty = new SimpleStringProperty();
		this.typeProperty = new SimpleObjectProperty<FlightType>();
		this.terminalProperty = new SimpleObjectProperty<Terminal>();
		this.flights = new Flights();
		this.flightsListProperty = new SimpleListProperty<FlightKey>(FXCollections.observableArrayList(this.flights.keys()));

	}

	/**
	 * Gets the airline property.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the airline property
	 */
	public StringProperty airlineProperty() {
		return this.airlineProperty;
	}

	/**
	 * Gets the aircraft property.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the airline property
	 */
	public StringProperty aircraftProperty() {
		return this.aircraftProperty;
	}

	/**
	 * Gets the type property.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the type property
	 */
	public ObjectProperty<FlightType> typeProperty() {
		return this.typeProperty;
	}

	/**
	 * Gets the terminal property.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the terminal property
	 */
	public ObjectProperty<Terminal> terminalProperty() {
		return this.terminalProperty;
	}

	/**
	 * Gets the types property.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the types property
	 */
	public ListProperty<FlightType> typesProperty() {
		return this.typesProperty;
	}

	/**
	 * Gets the terminals property.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the terminals property
	 */
	public ListProperty<Terminal> terminalsProperty() {
		return this.terminalsProperty;
	}
	/**
	 * Gets the flights list view property.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the flights list view property
	 */
	public ListProperty<FlightKey> flightsListProperty() {
		return this.flightsListProperty;
	}

	/**
	 * Adds the flight.
	 *
	 * @return true, if successful; false, otherwise
	 */
	public boolean addFlight() {
		FlightKey key = new FlightKey(this.airlineProperty.getValue(), this.aircraftProperty.getValue());
		FlightDetails details = new FlightDetails(this.typeProperty.getValue(), this.terminalProperty.getValue());
		this.flightsListProperty.add(key);
		return this.flights.add(key, details);
	}

	/**
	 * Updates the flight.
	 *
	 * @return true, if successful; false, otherwise
	 */
	public boolean updateFlight() {
		FlightKey key = new FlightKey(this.airlineProperty.getValue(), this.aircraftProperty.getValue());
		FlightDetails details = new FlightDetails(this.typeProperty.getValue(), this.terminalProperty.getValue());
		return this.flights.update(key, details);
	}

	/**
	 * Searches for the details of the flight with the specified airline and
	 * aircraft.
	 *
	 * @return details, if successful; null, otherwise
	 */
	public FlightDetails searchForFlight() {
		FlightKey key = new FlightKey(this.airlineProperty.getValue(), this.aircraftProperty.getValue());
		return this.flights.get(key);
	}

	/**
	 * Deletes the flight.
	 *
	 * @return true, if successful; false, otherwise
	 */
	public boolean deleteFlight() {
		FlightKey key = new FlightKey(this.airlineProperty.getValue(), this.aircraftProperty.getValue());
		this.flightsListProperty.remove(key);
		return this.flights.remove(key);
	}

	/**
	 * Gets the flights.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the flights
	 */
	public Flights getFlights() {
		return this.flights;
	}
}
