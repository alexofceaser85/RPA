package edu.westga.cs1302.airport.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.westga.cs1302.airport.resources.ExceptionMessages;

/**
 * Handles the data storing for all flights through the FlightKey and
 * FlightDetails.
 * 
 * @author Alexander Ayers
 *
 */
public class Flights {
	private final Map<FlightKey, FlightDetails> flights;
	/**
	 * Zero-parameter constructor
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public Flights() {
		this.flights = new HashMap<FlightKey, FlightDetails>();
	}

	/**
	 * Gets the total amount of flights.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the total amount of flights
	 */
	public int size() {
		return this.flights.size();
	}

	/**
	 * Determines whether the flights is empty or not and returns a boolean based on
	 * that result.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return whether the flights is empty or not
	 */
	public boolean isEmpty() {
		return this.flights.isEmpty();
	}

	/**
	 * Check if the list of flights contains the specified key or not.
	 * 
	 * @precondition key != null
	 * @postcondition none
	 * @param key the specified key
	 * @return whether the specified key is present or not
	 */
	public boolean containsKey(Object key) {
		if (key == null) {
			throw new NullPointerException(ExceptionMessages.NULL_FLIGHT_KEY);
		}
		return this.flights.containsKey(key);
	}

	/**
	 * Gets the flight details associated with the key
	 * 
	 * @precondition key != null
	 * @postcondition none
	 * @param key the specifed key
	 * @return the details of the flight asscioated with the key
	 */
	public FlightDetails get(FlightKey key) {
		if (key == null) {
			throw new NullPointerException(ExceptionMessages.NULL_FLIGHT_KEY);
		}
		return this.flights.get(key);
	}

	/**
	 * Removes the flight details asscoiated with the key. Checks if the value was
	 * removed or not
	 * 
	 * @precondition key != null
	 * @postcondition size() == @prev - 1
	 * @param key the key for the value to be removed
	 * @return whether the flight details was successfully removed or not.
	 */
	public boolean remove(FlightKey key) {
		if (key == null) {
			throw new NullPointerException(ExceptionMessages.NULL_FLIGHT_KEY);
		}
		return (this.flights.remove(key) == null);
	}

	/**
	 * Clears all flight details from the list of flights.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void clear() {
		this.flights.clear();
	}

	/**
	 * Adds the specified flight details to the specified key. Checks whether the
	 * flight details was successfully added.
	 * 
	 * @precondition key != null && flightDetails != null
	 * @postcondition size() == @prev + 1
	 * @param key           the specified key
	 * @param flightDetails the specified flightDetails
	 * @return whether the flightDetails was successfully added or not.
	 */
	public boolean add(FlightKey key, FlightDetails flightDetails) {
		if (key == null) {
			throw new NullPointerException(ExceptionMessages.NULL_FLIGHT_KEY);
		}
		if (flightDetails == null) {
			throw new NullPointerException(ExceptionMessages.NULL_FLIGHT_DETAILS);
		}
		if (this.containsKey(key) || this.flights.containsValue(flightDetails)) {
			return false;
		}

		return (this.flights.put(key, flightDetails) == null);

	}

	/**
	 * Updates the specified flight details at the specified key. Checks whether the
	 * flight details was successfully updated or not.
	 * 
	 * @precomdition key != null && flightDetails != null
	 * @postcondition size() == @prev && the value at flightDetails has been
	 *                updated.
	 * @param key           the specified key
	 * @param flightDetails the specified flightDetails
	 * @return whether the flightDetails was successfully added or not.
	 */
	public boolean update(FlightKey key, FlightDetails flightDetails) {
		if (key == null) {
			throw new NullPointerException(ExceptionMessages.NULL_FLIGHT_KEY);
		}
		if (flightDetails == null) {
			throw new NullPointerException(ExceptionMessages.NULL_FLIGHT_DETAILS);
		}
		if (!this.containsKey(key)) {
			return false;
		}
		return (this.flights.replace(key, flightDetails) == null);

	}

	/**
	 * Gets a collection of all keys present in the list of flightz.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return a collection of all keys present in the list of flights
	 */
	public Collection<FlightKey> keys() {
		List<FlightKey> keys = new ArrayList<FlightKey>();
		for (FlightKey currKey : this.flights.keySet()) {
			keys.add(currKey);
		}
		return keys;
	}

	/**
	 * Gets a collection of all flight details present in the list of flights.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return a collection of all flight details present in the list of flights
	 */
	public Collection<FlightDetails> values() {
		return this.flights.values();
	}
}
