package edu.westga.cs1302.airport.model;

/**
 * The enum TerminalType.
 * 
 * @author CS1302
 *
 */
public enum Terminal {

	INTERNATIONAL, DOMESTIC, REGIONAL

}
