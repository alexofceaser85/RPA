package edu.westga.cs1302.airport.model;

import edu.westga.cs1302.airport.resources.ExceptionMessages;

/**
 * The data class FlightDetails.
 * 
 * @author CS1302
 *
 */
public class FlightDetails {

	private FlightType type;
	private Terminal terminal;

	/**
	 * Creates the details of a flight with the specified arguments.
	 * 
	 * @precondition type != null && terminal != null
	 * @postcondition
	 * @param type     the specified type
	 * @param terminal the specified terminal
	 */
	public FlightDetails(FlightType type, Terminal terminal) {
		if (type == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_FLIGHT_TYPE);
		}
		if (terminal == null) {
			throw new IllegalArgumentException(ExceptionMessages.NULL_TERMINAL);
		}
		this.type = type;
		this.terminal = terminal;
	}

	/**
	 * Gets the type of fight.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the type of flight
	 */
	public FlightType getType() {
		return this.type;
	}

	/**
	 * Gets the terminal of the flight.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the terminal of the flight
	 */
	public Terminal getTerminal() {
		return this.terminal;
	}

	@Override
	public String toString() {
		return this.type + " " + this.terminal;
	}

}
