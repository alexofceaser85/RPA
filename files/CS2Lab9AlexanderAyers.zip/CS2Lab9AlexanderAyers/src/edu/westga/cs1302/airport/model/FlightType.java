package edu.westga.cs1302.airport.model;

/**
 * The enum FlightType.
 * 
 * @author CS1302
 *
 */
public enum FlightType {

	PUBLIC("Public"), PRIVATE("Private"), CHARTER("Charter"), CARGO("Cargo");

	private String description;

	FlightType(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return this.description;
	}
}
