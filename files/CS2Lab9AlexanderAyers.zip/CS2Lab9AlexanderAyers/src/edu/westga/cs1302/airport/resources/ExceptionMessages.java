package edu.westga.cs1302.airport.resources;

/**
 * Defines the exception messages.
 * 
 * @author CS1302
 */
public class ExceptionMessages {
	
	public static final String NULL_AIRLINE = "Airline cannot be null.";
	public static final String EMPTY_AIRLINE = "Airline cannot be empty.";
	public static final String NULL_AIRCRAFT = "Aircraft cannot be null.";
	public static final String EMPTY_AIRCRAFT = "Aircraft cannot be empty.";
	public static final String NULL_FLIGHT_TYPE = "Flight type cannot be null.";
	public static final String NULL_TERMINAL = "Terminal cannot be null.";
	public static final String NULL_FLIGHT_KEY = "Flight key cannot be null.";
	public static final String NULL_FLIGHT_DETAILS  = "Flight details cannot be null";
	public static final String ADD_ERROR = "Could not add Flight, please try again.";
	public static final String REMOVE_ERROR = "Could not remove flight, please try again";
	public static final String UPDATE_ERROR = "Could not update flight, please try again";
	public static final String SEARCH_ERROR = "Could not find the flight you requested. Please try again";
	
}
