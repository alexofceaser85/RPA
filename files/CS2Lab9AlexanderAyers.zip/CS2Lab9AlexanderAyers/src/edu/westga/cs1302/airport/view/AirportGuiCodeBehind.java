package edu.westga.cs1302.airport.view;

import javafx.fxml.FXML;
import edu.westga.cs1302.airport.model.FlightDetails;
import edu.westga.cs1302.airport.model.FlightKey;
import edu.westga.cs1302.airport.model.FlightType;
import edu.westga.cs1302.airport.model.Terminal;
import edu.westga.cs1302.airport.resources.ExceptionMessages;
import edu.westga.cs1302.airport.viewmodel.AirportViewModel;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

/**
 * This class represent the code behind AirpotGui.fxml
 * 
 * @author CS1302
 *
 */

public class AirportGuiCodeBehind {

	private AirportViewModel airportViewModel;

	@FXML
	private TextField airlineTextField;

	@FXML
	private TextField aircraftTextField;

	@FXML
	private ComboBox<FlightType> flightTypeComboBox;

	@FXML
	private ComboBox<Terminal> terminalComboBox;

	@FXML
	private ListView<FlightKey> flightsListView;

	@FXML
	private Button addButton;

	@FXML
	private Button updateButton;

	@FXML
	private Button removeButton;

	@FXML
	private Button searchButton;

	@FXML
	private Label errorLabel;

	/**
	 * Instantiates a new AirportGuiCodeBehind.
	 */
	public AirportGuiCodeBehind() {
		this.airportViewModel = new AirportViewModel();
	}

	@FXML
	private void initialize() {
		this.bindToViewModel();
		this.setupButtonDisabling();
		this.setupListViewChangeListener();
	}

	private void bindToViewModel() {
		this.airlineTextField.textProperty().bindBidirectional(this.airportViewModel.airlineProperty());
		this.aircraftTextField.textProperty().bindBidirectional(this.airportViewModel.aircraftProperty());
		this.airportViewModel.typeProperty().bind(this.flightTypeComboBox.getSelectionModel().selectedItemProperty());
		this.airportViewModel.terminalProperty().bind(this.terminalComboBox.getSelectionModel().selectedItemProperty());
		this.terminalComboBox.itemsProperty().bind(this.airportViewModel.terminalsProperty());
		this.flightTypeComboBox.itemsProperty().bind(this.airportViewModel.typesProperty());
		this.flightsListView.itemsProperty().bind(this.airportViewModel.flightsListProperty());
	}

	private void setupListViewChangeListener() {
		this.flightsListView.getSelectionModel().selectedItemProperty()
				.addListener((observable, oldValue, newValue) -> {
					this.airlineTextField.textProperty().setValue(newValue.getAirline());
					this.aircraftTextField.textProperty().setValue(newValue.getAircraft());
					this.terminalComboBox.getSelectionModel()
							.select(this.airportViewModel.getFlights().get(newValue).getTerminal());
					this.flightTypeComboBox.getSelectionModel()
							.select(this.airportViewModel.getFlights().get(newValue).getType());
				});
	}

	private void setupButtonDisabling() {
		BooleanBinding addUpdateBinding = this.flightTypeComboBox.getSelectionModel().selectedItemProperty().isNull()
				.or(this.terminalComboBox.getSelectionModel().selectedItemProperty().isNull())
				.or(this.airlineTextField.textProperty().isEmpty()).or(this.aircraftTextField.textProperty().isEmpty());

		this.addButton.disableProperty().bind(addUpdateBinding);
		this.updateButton.disableProperty()
				.bind(addUpdateBinding.or(Bindings.isEmpty(this.flightsListView.getItems())));

		BooleanBinding searchRemoveBinding = Bindings.or(this.airlineTextField.textProperty().isEmpty(),
				this.aircraftTextField.textProperty().isEmpty());
		this.searchButton.disableProperty().bind(searchRemoveBinding);
		this.removeButton.disableProperty().bind(searchRemoveBinding);

	}

	@FXML
	void handleAddFlight(ActionEvent event) {
		if (!this.airportViewModel.addFlight()) {
			this.errorLabel.setText(ExceptionMessages.ADD_ERROR);
		} else {
			this.errorLabel.setText("");
		}
		this.clearForm();
	}

	@FXML
	void handleRemoveFlight(ActionEvent event) {
		if (!this.airportViewModel.deleteFlight()) {
			this.errorLabel.setText(ExceptionMessages.REMOVE_ERROR);
		} else {
			this.errorLabel.setText("");
		}
		this.clearForm();
	}

	@FXML
	void handleSearchFlight(ActionEvent event) {
		FlightDetails match = this.airportViewModel.searchForFlight();

		if (match == null) {
			this.errorLabel.setText(ExceptionMessages.SEARCH_ERROR);
		} else {
			this.terminalComboBox.getSelectionModel().select(match.getTerminal());
			this.flightTypeComboBox.getSelectionModel().select(match.getType());
			this.errorLabel.setText("");
		}
		this.clearForm();
	}

	@FXML
	void handleUpdateFlight(ActionEvent event) {
		if (!this.airportViewModel.updateFlight()) {
			this.errorLabel.setText(ExceptionMessages.UPDATE_ERROR);
		} else {
			this.errorLabel.setText("");
		}
		this.clearForm();
	}

	private void clearForm() {
		this.airlineTextField.setText("");
		this.aircraftTextField.setText("");
		this.flightTypeComboBox.getSelectionModel().clearSelection();
		this.terminalComboBox.getSelectionModel().clearSelection();
		this.flightsListView.getSelectionModel().clearSelection();
		this.errorLabel.setText("");
	}

}
