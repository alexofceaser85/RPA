package edu.westga.cs1302.airport.model;


import edu.westga.cs1302.airport.resources.ExceptionMessages;

/**
 * Models a key for the flight.
 * 
 * @author Alexander Ayers
 *
 */
public class FlightKey {
	private String airline;

	private String aircraft;

	/**
	 * Two-parameter constructor.
	 * 
	 * @precondition airline != null && !airline.isBlank() && aircraft != null &&
	 *               !aircraft.isBlank()
	 * @postcondition getAirline() == airline && getAircraft() == aircraft
	 * @param airline  the specified airline
	 * @param aircraft the specified aircraft
	 */
	public FlightKey(String airline, String aircraft) {
		if (airline.equals(null)) {
			throw new NullPointerException(ExceptionMessages.NULL_AIRLINE);
		}
		if (airline.isBlank()) {
			throw new IllegalArgumentException(ExceptionMessages.EMPTY_AIRLINE);
		}
		if (aircraft.equals(null)) {
			throw new NullPointerException(ExceptionMessages.NULL_AIRCRAFT);
		}
		if (aircraft.isBlank()) {
			throw new IllegalArgumentException(ExceptionMessages.EMPTY_AIRCRAFT);
		}

		this.airline = airline;
		this.aircraft = aircraft;
	}

	/**
	 * Gets the airline.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the airline
	 */
	public String getAirline() {
		return this.airline;
	}

	/**
	 * Gets the aircraft.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the aircraft
	 */
	public String getAircraft() {
		return this.aircraft;
	}

	@Override
	public boolean equals(Object flightKey) {
		if (flightKey instanceof FlightKey) {
			return ((FlightKey) flightKey).getAircraft().equals(this.aircraft)
					&& ((FlightKey) flightKey).getAirline().equals(this.airline);
		}
		return false;
	}

	@Override
	public int hashCode() {
		String fullKey = this.airline + this.aircraft;
		return fullKey.hashCode();
	}
	
	@Override
	public String toString() {
		return this.airline + " " + this.aircraft;
	}
}
