package edu.westga.cs3152.sets;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * Class SortedSet
 * 
 * An implementation of the Set interface that stores the elements in sorted
 * order using the natural order on the elements. The natural order of the
 * elements has to be consistent with the equals operator, i.e.
 * el1.compareTo(el2) is 0 if and only if el1.equals(el2). The operations size
 * and isEmpty run in constant time. Operation contains runs in logarithmic
 * time. All other operations guarantee linear time complexity. The iterator
 * returns the elements in sorted order.
 * 
 * @author CS3152
 * @version Fall 2021
 * @param <E> type of set elements
 */
public class SortedSet<E extends Comparable<E>> implements Set<E> {

	private static final String SET_NOT_A_SORTED_SET_MESSAGE = "aSet needs to be of type SortedSet";
	private HashSet<E> iterationSet;
	private LinkedList<E> sorter;

	/**
	 * Instantiates a new MySet object.
	 */
	public SortedSet() {
		this.iterationSet = new HashSet<E>();
		this.sorter = new LinkedList<E>();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#size()
	 */
	@Override
	public int size() {
		return this.iterationSet.size();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#isEmpty()
	 */
	@Override
	public boolean isEmpty() {
		return this.iterationSet.isEmpty();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#equals(edu.westga.cs3152.sets.Set)
	 * 
	 * @throws ClassCastException if the specified set is not a SortedSet
	 */
	@Override
	public boolean equals(Set<E> aSet) throws ClassCastException {
		this.throwAndHandleSetIsNull(aSet);
		this.checkIfSetIsSortedSet(aSet);
		for (E current : aSet) {
			if (!this.iterationSet.contains(current)) {
				return false;
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#isSubsetOf(edu.westga.cs3152.sets.Set)
	 * 
	 * @throws ClassCastException if the specified set is not a SortedSet
	 */
	@Override
	public boolean isSubsetOf(Set<E> aSet) throws ClassCastException {
		this.throwAndHandleSetIsNull(aSet);
		this.checkIfSetIsSortedSet(aSet);

		for (E current : this.iterationSet) {
			if (!aSet.contains(current)) {
				return false;
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#isProperSubsetOf(edu.westga.cs3152.sets.Set)
	 * 
	 * @throws ClassCastException if the specified set is not a SortedSet
	 */
	@Override
	public boolean isProperSubsetOf(Set<E> aSet) throws ClassCastException {
		this.throwAndHandleSetIsNull(aSet);
		this.checkIfSetIsSortedSet(aSet);
		if (this.equals(aSet)) {
			return false;
		}
		return this.isSubsetOf(aSet);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#isDisjoint(edu.westga.cs3152.sets.Set)
	 * 
	 * @throws ClassCastException if the specified set is not a SortedSet
	 */
	@Override
	public boolean isDisjoint(Set<E> aSet) throws ClassCastException {
		this.throwAndHandleSetIsNull(aSet);
		this.checkIfSetIsSortedSet(aSet);
		for (E current : aSet) {
			if (this.contains(current)) {
				return false;
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#contains(java.lang.Object)
	 */
	@Override
	public boolean contains(E el) {
		this.throwAndHandleSetIsNull(el);
		return this.iterationSet.contains(el);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#add(java.lang.Object)
	 */
	@Override
	public boolean add(E el) {
		this.throwAndHandleSetIsNull(el);
		this.iterationSet.add(el);
		int index = 0;
		for (E current : this.sorter) {
			if (current.compareTo(el) > 0) {
				break;
			}
			index++;
		}
		this.sorter.add(index, el);
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#remove(java.lang.Object)
	 */
	@Override
	public boolean remove(E el) {
		this.throwAndHandleSetIsNull(el);
		this.iterationSet.remove(el);
		return this.sorter.remove(el);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.datastructures.sets.Set#union(edu.westga.cs3152.sets.Set)
	 * 
	 * @throws ClassCastException if the specified set is not a SortedSet
	 */
	@Override
	public Set<E> union(Set<E> aSet) {
		this.throwAndHandleSetIsNull(aSet);
		this.checkIfSetIsSortedSet(aSet);

		SortedSet<E> union = new SortedSet<E>();

		ArrayList<E> leftSet = new ArrayList<E>(((SortedSet<E>) aSet).getSortedSet());
		ArrayList<E> rightSet = new ArrayList<E>(this.sorter);

		int leftSetSize = leftSet.size();
		int rightSetSize = rightSet.size();

		int leftIndex = 0;
		int rightIndex = 0;

		while (leftIndex < leftSetSize && rightIndex < rightSetSize) {
			if (leftSet.get(leftIndex).compareTo(rightSet.get(rightIndex)) < 0) {
				leftIndex = this.updateSet(union, leftSet, leftIndex);
			} else {
				rightIndex = this.updateSet(union, rightSet, rightIndex);
			}
		}

		this.copyRemainingItemsInSet(union, leftSet, leftSetSize, leftIndex);
		this.copyRemainingItemsInSet(union, rightSet, rightSetSize, rightIndex);

		return union;
	}
	
	private void throwAndHandleSetIsNull(Set<E> aSet) {
		if (aSet == null) {
			throw new IllegalArgumentException("Set cannot be null.");
		}
	}
	
	private void throwAndHandleSetIsNull(E element) {
		if (element == null) {
			throw new IllegalArgumentException("The element cannot be null.");
		}
	}
	
	private void copyRemainingItemsInSet(SortedSet<E> union, ArrayList<E> set, int setSize, int index) {
		while (index < setSize) {
			index = this.updateSet(union, set, index);
		}
	}

	private int updateSet(SortedSet<E> union, ArrayList<E> setToUpdate, int index) {
		union.addTail(setToUpdate.get(index));
		index++;
		return index;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#intersection(edu.westga.cs3152.sets.Set)
	 * 
	 * @throws ClassCastException if the specified set is not a SortedSet
	 */
	@Override
	public Set<E> intersection(Set<E> aSet) {
		this.throwAndHandleSetIsNull(aSet);
		this.checkIfSetIsSortedSet(aSet);
		SortedSet<E> intersection = new SortedSet<E>();

		for (E current : aSet) {
			if (this.contains(current)) {
				intersection.addTail(current);
			}
		}
		return intersection;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.westga.cs3152.sets.Set#difference(edu.westga.cs3152.sets.Set)
	 * 
	 * @throws ClassCastException if the specified set is not a SortedSet
	 */
	@Override
	public Set<E> difference(Set<E> aSet) {
		this.throwAndHandleSetIsNull(aSet);
		this.checkIfSetIsSortedSet(aSet);
		SortedSet<E> difference = new SortedSet<E>();

		for (E current : this.sorter) {
			if (!aSet.contains(current)) {
				difference.addTail(current);
			}
		}

		return difference;
	}

	/**
	 * Gets the sorted set
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the sorted set.
	 */
	public LinkedList<E> getSortedSet() {
		return this.sorter;
	}

	private void checkIfSetIsSortedSet(Set<E> aSet) throws ClassCastException {
		if (!(aSet instanceof SortedSet<?>)) {
			throw new ClassCastException(SET_NOT_A_SORTED_SET_MESSAGE);
		}
	}

	private void addTail(E el) {
		this.iterationSet.add(el);
		this.sorter.addLast(el);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Iterable#iterator()
	 */
	@Override
	public Iterator<E> iterator() {
		return this.sorter.iterator();
	}

}