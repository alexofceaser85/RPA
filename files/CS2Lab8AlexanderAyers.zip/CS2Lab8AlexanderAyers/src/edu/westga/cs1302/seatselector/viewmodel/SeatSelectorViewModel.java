package edu.westga.cs1302.seatselector.viewmodel;

import edu.westga.cs1302.seatselector.model.Plane;
import edu.westga.cs1302.seatselector.model.Seat;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * The Class SeatSelectorViewModel.
 * 
 * @author CS1302
 */
public class SeatSelectorViewModel {
	private final ObjectProperty<Seat> seatProperty;
	private final IntegerProperty numberAvailableSeatsProperty;
	private final IntegerProperty numberReservedSeatsProperty;
	private final StringProperty seatDetailsProperty;
	private final StringProperty totalCostProperty;

	private Plane plane;

	/**
	 * Instantiates a new GUI view model.
	 */
	public SeatSelectorViewModel() {
		this.plane = new Plane();
		this.seatProperty = new SimpleObjectProperty<Seat>();
		this.numberAvailableSeatsProperty = new SimpleIntegerProperty(this.plane.getNumberAvailableSeats());
		this.numberReservedSeatsProperty = new SimpleIntegerProperty(this.plane.getNumberBookedSeats());
		this.seatDetailsProperty = new SimpleStringProperty();
		this.totalCostProperty = new SimpleStringProperty();
	}

	/**
	 * Gets the selected seat property.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the selected seat property
	 */
	public ObjectProperty<Seat> selectedSeatProperty() {
		return this.seatProperty;
	}

	/**
	 * Gets the seat details property
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the seat details property
	 */
	public StringProperty seatDetailsProperty() {
		return this.seatDetailsProperty;
	}

	/**
	 * Gets the number of reserved seats property.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the number of reserved seats property
	 */
	public IntegerProperty numberReservedSeatsProperty() {
		return this.numberReservedSeatsProperty;
	}

	/**
	 * Gets the number of available seats property.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the number of available seats property
	 */
	public IntegerProperty numberAvailableSeatsProperty() {
		return this.numberAvailableSeatsProperty;
	}

	/**
	 * Gets the number of total cost property.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the number of total cost property
	 */
	public StringProperty totalCostProperty() {
		return this.totalCostProperty;
	}

	/**
	 * Books the seat with the specified id
	 * 
	 * @precondition none
	 * @postcondition none
	 * @param id the id of the seat
	 */
	public void selectSeat(String id) {
		this.plane.bookSeat(id);
		this.updateNumberOfSeats();

	}

	/**
	 * Unbooks the seat with the specified id
	 * 
	 * @precondition none
	 * @postcondition none
	 * @param id the id of the seat
	 */
	public void deselectSeat(String id) {
		this.plane.unbookSeat(id);
		this.updateNumberOfSeats();
	}

	/**
	 * Books the selected seats.
	 * 
	 * @precondition none
	 * @postcondition booked seats become unavailable
	 */
	public void bookSeats() {
		this.plane.bookReservedSeats();
	}

	private void updateNumberOfSeats() {
		this.numberAvailableSeatsProperty.setValue(this.plane.getNumberAvailableSeats());
		this.numberReservedSeatsProperty.setValue(this.plane.getNumberBookedSeats());
		this.totalCostProperty.setValue(this.plane.getFormattedPriceSelectedSeats());
	}
}
