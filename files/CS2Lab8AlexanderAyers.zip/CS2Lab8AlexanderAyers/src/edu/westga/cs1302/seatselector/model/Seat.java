package edu.westga.cs1302.seatselector.model;

/**
 * This class represets a seat on a plane.
 * 
 * @author CS 1302
 *
 */
public class Seat {
	private static final int INITIAL_SEAT_PRICE = 300;
	private static final int MIDDLE_SEAT_DISCOUNT = 10;
	private static final int SEAT_ROW_DISCOUNT = 25;
	private static final String AISLE_SEAT = "aisle";
	private static final String MIDDLE_SEAT = "middle";
	private static final String WINDOW_SEAT = "window";
	private int seatNumber;
	private boolean reserved;
	private boolean booked;

	/**
	 * Creates a seat with the specified number.
	 * 
	 * @precondition none
	 * @postcondition getSeatNumber() == seatNumber && !isReserved() && !isBooked()
	 * @param seatNumber the number of this seat
	 */
	public Seat(int seatNumber) {
		this.seatNumber = seatNumber;
		this.reserved = false;
	}

	/**
	 * Returns the booking status of this seat.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return true if seat booked
	 */
	public boolean isBooked() {
		return this.booked;
	}

	/**
	 * Sets the booking status of this seat.
	 * 
	 * @precondition none
	 * @postcondition isBooked()
	 */
	public void book() {
		if (this.booked) {
			throw new IllegalArgumentException("Can't book an already booked seat.");
		}
		if (!this.isReserved()) {
			throw new IllegalArgumentException("Reserve seat first.");
		}
		this.booked = true;
	}

	/**
	 * Creates a seat with the specified number.
	 * 
	 * @precondition id a string of the form seatX, where X is a number from 1 to 30
	 * @postcondition creates seat with specified number
	 * @param id string is for seat
	 */
	public Seat(String id) {
		String seatId = id.substring("seat".length(), id.length());
		this.seatNumber = Integer.parseInt(seatId);
	}

	/**
	 * Returns true if this seat is reserved.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return true if this seat is reserved, false otherwise
	 */
	public boolean isReserved() {
		return this.reserved;
	}

	/**
	 * Gets the seat number
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the row number
	 */
	public int getSeatNumber() {
		return this.seatNumber;
	}

	/**
	 * Reserves this sear.
	 * 
	 * @precondition none
	 * @postcondition isReserved()
	 */
	public void reserve() {
		if (this.reserved) {
			throw new IllegalArgumentException("Already reserved.");
		}
		this.reserved = true;
	}

	/**
	 * Cancels reservation of this seat.
	 * 
	 * @precondition none
	 * @postcondition !isReserved()
	 */
	public void unreserve() {
		this.reserved = false;

	}

	@Override
	public String toString() {
		String details = "Seat ";
		details += this.seatNumber + " (" + this.getType() + ")";
		return details;
	}

	private String getType() {
		String seatType = "";
		int columnOfSeat = this.seatNumber % 5;
		if (columnOfSeat == 3 || columnOfSeat == 4) {
			seatType = Seat.AISLE_SEAT;
		} else if (columnOfSeat  == 2) {
			seatType = Seat.MIDDLE_SEAT;
		} else {
			seatType = Seat.WINDOW_SEAT;
		}
		return seatType;
	}

	/**
	 * Returns the price of this seat.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the price of this seat
	 */
	public double getPrice() {
		double seatPrice = Seat.INITIAL_SEAT_PRICE;
		if (this.getType().equals(Seat.MIDDLE_SEAT)) {
			seatPrice -= Seat.MIDDLE_SEAT_DISCOUNT;
		}
		for (int counter = 1; counter <= 5; counter++) {
			int rowNumber = counter * 5;
			if (this.getSeatNumber() > rowNumber) {
				seatPrice -= Seat.SEAT_ROW_DISCOUNT;
			}
		}
		return seatPrice;
	}
}
