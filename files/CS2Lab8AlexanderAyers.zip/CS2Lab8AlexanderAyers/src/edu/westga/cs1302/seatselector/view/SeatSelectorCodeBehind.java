package edu.westga.cs1302.seatselector.view;

import edu.westga.cs1302.seatselector.model.Seat;
import edu.westga.cs1302.seatselector.viewmodel.SeatSelectorViewModel;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.converter.NumberStringConverter;

/**
 * Class SeatSelectorCodeBehind
 * 
 * @author CS 1302
 *
 */
public class SeatSelectorCodeBehind {

	private SeatSelectorViewModel viewmodel;
	private ObjectProperty<Seat> selectedSeatProperty;

	@FXML
	private GridPane seatGrid;

	@FXML
	private Label totalCostLabel;

	@FXML
	private Label seatDetailsLabel;

	@FXML
	private Label numberReservedSeatsLabel;

	@FXML
	private Label numberAvailableSeatsLabel;

	@FXML
	private Button bookButton;

	/**
	 * Instantiates a new code behind.
	 */
	public SeatSelectorCodeBehind() {
		this.viewmodel = new SeatSelectorViewModel();
		this.selectedSeatProperty = new SimpleObjectProperty<Seat>();
	}

	@FXML
	void initialize() {
		this.bindToViewModel();
		this.setupChangeListeners();
		this.setupEventHandlers();
	}

	private void bindToViewModel() {
		this.selectedSeatProperty.bindBidirectional(this.viewmodel.selectedSeatProperty());
		this.numberAvailableSeatsLabel.textProperty().bindBidirectional(this.viewmodel.numberAvailableSeatsProperty(),
				new NumberStringConverter());
		this.numberReservedSeatsLabel.textProperty().bindBidirectional(this.viewmodel.numberReservedSeatsProperty(),
				new NumberStringConverter());
		this.seatDetailsLabel.textProperty().bindBidirectional(this.viewmodel.seatDetailsProperty());
		this.totalCostLabel.textProperty().bindBidirectional(this.viewmodel.totalCostProperty());
	}

	private void setupChangeListeners() {
		this.selectedSeatProperty.addListener((observable, oldSeat, newSeat) -> {
			this.seatDetailsLabel.textProperty().setValue(newSeat.toString());

		});
	}

	private void setupEventHandlers() {
		this.bookButton.setOnAction((event) -> {
			this.viewmodel.bookSeats();

			for (Node currNode : this.seatGrid.getChildren()) {
				Rectangle currSeat = (Rectangle) currNode;

				if (currSeat.getFill().equals(Color.RED)) {
					currSeat.setFill(Color.BLACK);
					this.seatDetailsLabel.setVisible(false);
				}
			}

		});
	}

	@FXML
	private void selectSeat(MouseEvent event) {
		Node node = (Node) event.getSource();
		Rectangle rectangle = (Rectangle) node;
		String id = node.getId();
		if (rectangle.getFill().equals(Color.RED)) {
			rectangle.setFill(Color.DODGERBLUE);
			this.viewmodel.deselectSeat(id);
			this.seatDetailsLabel.setVisible(false);
		} else if (rectangle.getFill().equals(Color.DODGERBLUE)) {
			rectangle.setFill(Color.RED);
			this.viewmodel.selectSeat(id);
			this.seatDetailsLabel.setVisible(true);
		} else if (rectangle.getFill().equals(Color.BLACK)) {
			this.seatDetailsLabel.setVisible(false);
		}
		Seat seat = new Seat(id);
		this.selectedSeatProperty.set(seat);
	}
}