package edu.westga.cs1302.seatselector.model;

import java.text.NumberFormat;

/**
 * The class Plane.
 * 
 * @author CS 1302
 *
 */
public class Plane {

	private Seat[] seats;
	private static final int NUMBER_SEATS = 30;

	/**
	 * Instantiates a plane.
	 * 
	 * @precondition none
	 * @postcondition size() == 30
	 */
	public Plane() {
		this.seats = new Seat[NUMBER_SEATS];
		for (int number = 0; number < NUMBER_SEATS; number++) {
			this.seats[number] = new Seat(number + 1);
		}
	}

	/**
	 * Gets the number of seats on this plane.
	 * 
	 * @precondition none
	 * @postcondition size() == 30
	 * @return the size of this plane.
	 */
	public int size() {
		return NUMBER_SEATS;
	}

	/**
	 * Gets the number of available sseats on this plane.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the number of available seats
	 */
	public int getNumberAvailableSeats() {
		int counter = 0;
		for (Seat seat : this.seats) {
			if (!seat.isReserved()) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * Gets the number of booked seats on this plane.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the number of booked seats
	 */
	public int getNumberBookedSeats() {
		int counter = 0;
		for (Seat seat : this.seats) {
			if (seat.isReserved()) {
				counter++;
			}
		}
		return counter;
	}

	/**
	 * Books the specified seat
	 * 
	 * @precondition id a string of the form seatX, where X is a number from 1 to 30
	 * @postcondition seat with specified id is booked
	 * @param id the id of the seat
	 */
	public void bookSeat(String id) {
		String seatId = id.substring("seat".length(), id.length());
		int seatNumber = Integer.parseInt(seatId);
		this.seats[seatNumber - 1].reserve();
	}

	/**
	 * Unbooks this seat
	 * 
	 * @precondition id a string of the form seatX, where X is a number from 1 to 30
	 * @postcondition seat with id is now available
	 * @param id the id of the seat
	 */
	public void unbookSeat(String id) {
		String seatId = id.substring("seat".length(), id.length());
		int seatNumber = Integer.parseInt(seatId);
		this.seats[seatNumber - 1].unreserve();
	}

	/**
	 * Gets the formatted price of all selected seats.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return total price formatted to local currency
	 */
	public String getFormattedPriceSelectedSeats() {
		NumberFormat defaultFormat = NumberFormat.getCurrencyInstance();
		return defaultFormat.format(this.getPriceSelectedSeats());
	}

	/**
	 * Gets the price of all selected seats.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return total price of selected seats
	 */
	public double getPriceSelectedSeats() {
		double total = 0;
		for (Seat seat : this.seats) {
			if (seat.isReserved() && !seat.isBooked()) {
				total += seat.getPrice();
			}
		}
		return total;
	}

	/**
	 * Books the reserved seats.
	 * 
	 * @precondition none
	 * @postcondition reserved seats are now booked
	 */
	public void bookReservedSeats() {
		for (Seat seat : this.seats) {
			if (seat.isReserved() && !seat.isBooked()) {
				seat.book();
			}
		}
	}
}
