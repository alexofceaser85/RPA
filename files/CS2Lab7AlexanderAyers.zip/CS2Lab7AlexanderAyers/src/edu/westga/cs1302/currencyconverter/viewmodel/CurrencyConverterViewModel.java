package edu.westga.cs1302.currencyconverter.viewmodel;

import java.text.DecimalFormat;

import edu.westga.cs1302.currencyconverter.model.ConversionRate;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * The view model for the currency converter.
 * 
 * @author Alexander Ayers
 *
 */
public class CurrencyConverterViewModel {
	private static final String INVALID_CURRENCY = "Please use the three letter currency codes.";

	private StringProperty errorMessage;
	private DoubleProperty amountProperty;
	private StringProperty conversionTypeProperty;
	private StringProperty resultProperty;

	public CurrencyConverterViewModel() {
		this.errorMessage = new SimpleStringProperty();
		this.amountProperty = new SimpleDoubleProperty();
		this.resultProperty = new SimpleStringProperty();
		this.conversionTypeProperty = new SimpleStringProperty();
	}

	/**
	 * Gets the amount,
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the amount
	 */
	public DoubleProperty getAmountProperty() {
		return this.amountProperty;
	}

	/**
	 * Gets the conversion type.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the conversion type
	 */
	public StringProperty getConversionTypeProperty() {
		return this.conversionTypeProperty;
	}

	/**
	 * Gets the result.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the result
	 */
	public StringProperty getResultProperty() {
		return this.resultProperty;
	}

	/**
	 * Formats the result property into the proper result.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void formatResultProperty() {
		DecimalFormat format = new DecimalFormat();
		this.resultProperty.setValue("$" + format.format(this.amountProperty.doubleValue()) + " = "
				+ format.format(this.convertAmount()) + this.checkConversionRateType());
		if (this.checkConversionRateType() == null) {
			this.resultProperty.setValue("");
		}
	}

	/**
	 * Checks the conversion type. If the conversion type matches any of the
	 * currency values, returns specified value. Otherwise, returns null.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the conversion type if matches, null otherwise.
	 * @throws NullPointerException If currency does not match a type.
	 */
	public ConversionRate checkConversionRateType() throws NullPointerException {
		ConversionRate currency = null;
		try {
			switch (this.conversionTypeProperty.getValue()) {
				default:
					break;
				case "AUD":
					currency = ConversionRate.AUD;
					break;
				case "CAD":
					currency = ConversionRate.CAD;
					break;
				case "CNY":
					currency = ConversionRate.CNY;
					break;
				case "EUR":
					currency = ConversionRate.EUR;
					break;
				case "GBP":
					currency = ConversionRate.GBP;
					break;
				case "INR":
					currency = ConversionRate.INR;
					break;
				case "JPY":
					currency = ConversionRate.JPY;
					break;
			}
		} catch (NullPointerException e) {
			this.errorMessage.setValue(CurrencyConverterViewModel.INVALID_CURRENCY);
		}
		return currency;
	}

	/**
	 * Converts the amount of currency using the conversion type specified in the
	 * GUI into an appropiate number.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the converted amount
	 */
	public double convertAmount() {
		double convertedAmount = 0;
		try {
			ConversionRate currency = this.checkConversionRateType();
			this.errorMessage.setValue("");
			convertedAmount = currency.exchange(this.amountProperty.doubleValue());
		} catch (NullPointerException e) {
			this.errorMessage.setValue(CurrencyConverterViewModel.INVALID_CURRENCY);
		}
		return convertedAmount;
	}

	/**
	 * Gets the error message.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the error message
	 */
	public StringProperty getErrorMessage() {
		return this.errorMessage;
	}
}
