package edu.westga.cs1302.currencyconverter.view;

import edu.westga.cs1302.currencyconverter.viewmodel.CurrencyConverterViewModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.util.converter.NumberStringConverter;
/**
 * Handles the code behind the GUI of the currency converter.
 * @author Alexander Ayers
 *
 */
public class CurrencyConverterCodeBehind {

    @FXML
    private TextField amountTextField;

    @FXML
    private TextField convertTextField;

    @FXML
    private Button convertButton;

    @FXML
    private TextArea displayTextArea;

    @FXML
    private Label errorMessage;
    
    private CurrencyConverterViewModel viewModel;
    
    /**
     * Zero-parameter constructor
     * 
     * @precondition none
     * @postcondition none
     */
    public CurrencyConverterCodeBehind() {
    	this.viewModel = new CurrencyConverterViewModel();
    }
    @FXML
    public void initialize() {
    	this.displayTextArea.setEditable(false);
    	
    	this.bindToViewModel();
    }
    
    private void bindToViewModel() {
    	this.amountTextField.textProperty().bindBidirectional(this.viewModel.getAmountProperty(), new NumberStringConverter());
    	this.displayTextArea.textProperty().bindBidirectional(this.viewModel.getResultProperty());
    	this.errorMessage.textProperty().bindBidirectional(this.viewModel.getErrorMessage());
    	
    	this.convertTextField.textProperty().bindBidirectional(this.viewModel.getConversionTypeProperty());
    }
    
    @FXML
    public void handleConvert(ActionEvent event) {
    	this.viewModel.formatResultProperty();
    }

}

