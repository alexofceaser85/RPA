package edu.westga.cs3152.model;

import java.io.FileNotFoundException;

import edu.westga.cs3152.data.CNFFileReader;

/**
 * Class CNF
 * 
 * Represents a CNF formula and an assignment to its logic variables. The
 * assignment may be partial, i.e.e not all variables have to be assigned a
 * truth value. Value 1 represents TRUE, value -1 represents FALSE, and 0 is
 * used to represent no current value.
 * 
 * @author CS3152
 * @version Fall 2021
 */
public class CNF {
	private static final String VARIABLE_MUST_BE_BETWEEN_1_AND_THE_NUMBER_OF_VARIABLES = "Variable must be between 1 and the number of variables.";
	private int[][] clausesMatrix;
	private int[] clauseStates;
	private int[][] variableMatrix;
	private int numberOfVariables;
	private int numberOfClauses;
	private int[] variableTruthValues;
	private int overallTruthValue;
	private int numberOfFalseClauses;
	private int numberOfTrueClauses;

	/**
	 * Instantiates a new CNF object and sets it to the CNF formula specified in the
	 * given file. The file conforms to the simplified DIMACS format: (Adapted from
	 * http://www.satcompetition.org/2009/format-benchmarks2009.html)
	 * 
	 * The file can start with comment lines, but does not have to. A comment line
	 * starts with the character c in the first column.
	 * 
	 * Right after the comments, there is the line "p cnf nbvar nbclauses"
	 * indicating that the instance is in CNF format; nbvar is the exact number of
	 * variable appearing in the file; nbclauses is the exact number of clauses
	 * contained in the file.
	 * 
	 * Then the clauses follow. Each clause is a sequence of distinct non-null
	 * numbers between -nbvar and nbvar ending with 0 on the same line; it cannot
	 * contain the opposite literals i and -i simultaneously and it cannot contain
	 * the same literal twice. Positive numbers denote the corresponding variables.
	 * Negative numbers denote the negations of the corresponding variables.
	 * 
	 * @pre filename is the name of a file which must meet the simplified DIMACS
	 *      format
	 * @post This CNF object represents the CNF formula specified in the given file.
	 *       No variables are set to a value.
	 * @param filename the name of the file with the CNF instance
	 * @throws IllegalArgumentException if the specified file does not exist or if
	 *                                  the specified file does not meet the DIMACS
	 *                                  format
	 */
	public CNF(String filename) {
		CNFFileReader reader = new CNFFileReader();

		try {
			reader.readFile(filename);
		} catch (FileNotFoundException exception) {
			exception.printStackTrace();
		}

		this.numberOfClauses = reader.getNumberOfClauses();
		this.numberOfVariables = reader.getNumberOfVariables();
		this.clausesMatrix = reader.getClauseMatrix();
		this.overallTruthValue = 0;
		this.variableMatrix = reader.getVariableMatrix();
		this.variableTruthValues = new int[this.numberOfVariables];
		this.clauseStates = new int[this.numberOfClauses];
	}

	/**
	 * Gets the number of logic variables in this CNF formula.
	 * 
	 * @pre none
	 * @post none
	 * @return number variables
	 */
	public int numberVariables() {
		return this.numberOfVariables;
	}

	/**
	 * Gets the number of clauses of this CNF formula.
	 * 
	 * @pre none
	 * @post none
	 * @return number clauses
	 */
	public int numberClauses() {
		return this.numberOfClauses;
	}

	/**
	 * Gets the value of the formula under the current assignment. The returned
	 * value is 1 if all clauses are true, -1 if one or more clauses are false, and
	 * 0 otherwise
	 * 
	 * @pre none
	 * @post none
	 * @return the current value of this formula
	 */
	public int getValue() {
		return this.overallTruthValue;
	}

	/**
	 * Gets the current value of the specified variable.
	 * 
	 * @pre none
	 * @post none
	 * @param var the variable of which the value is returned
	 * @return the value of this variable
	 */
	public int getValue(int var) {
		return this.variableTruthValues[var - 1];
	}

	/**
	 * Sets the specified variable to the specified value and updates the value of
	 * this CNF formula.
	 * 
	 * @pre 1 <= var <= numberVariables() AND val is element of {-1, 1} AND
	 *      getValue(var) = 0
	 * @post getValue(var) = val
	 * @param var variable to be set
	 * @param val the new variable value
	 * @return 1 if all clauses are true, -1 if one or more clauses are false, and 0
	 *         otherwise
	 * @throws IllegalArgumentException if the precondition is not met
	 */
	public int set(int var, int val) {
		if (var < 1 || var > this.numberOfVariables) {
			throw new IllegalArgumentException(VARIABLE_MUST_BE_BETWEEN_1_AND_THE_NUMBER_OF_VARIABLES);
		}
		if (val == 0 || val < -1 || val > 1) {
			throw new IllegalArgumentException("Value must be either -1 and 1.");
		}
		if (this.getValue(var) != 0) {
			throw new IllegalArgumentException("Value must be unknown before trying to set a value");
		}
		this.variableTruthValues[var - 1] = val;
		return this.updateTruthValuesForSet(var);
	}

	private int updateTruthValuesForSet(int var) {

		for (int clause : this.variableMatrix[var - 1]) {
			int clauseState = 0;
			for (int variable : this.clausesMatrix[Math.abs(clause) - 1]) {
				int currentTruthValue = this.variableTruthValues[Math.abs(variable) - 1];
				if (currentTruthValue == 1 && variable > 0 || currentTruthValue == -1 && variable < 0) {
					clauseState = 1;
					break;
				} else if (currentTruthValue != 0) {
					clauseState = -1;
				}
			}
			if (this.clauseStates[Math.abs(clause) - 1] != 1 && clauseState == 1) {
				this.numberOfTrueClauses++;
			} else if (this.clauseStates[Math.abs(clause) - 1] != -1 && clauseState == -1) {
				this.numberOfFalseClauses++;
			}
			this.clauseStates[Math.abs(clause) - 1] = clauseState;
		}
		if (this.numberOfTrueClauses == this.numberOfClauses) {
			this.overallTruthValue = 1;
		} else if (this.numberOfTrueClauses + this.numberOfFalseClauses == this.numberOfClauses) {
			this.overallTruthValue = -1;
		} else {
			this.overallTruthValue = 0;
		}

		return this.overallTruthValue;
	}

	/**
	 * Unsets the specified variable and updates the value of this CNF formula.
	 * 
	 * @pre 1 <= var <= numberVariables() AND getValue(var) is element of {-1, 1}
	 * @post getValue(var) = 0
	 * @param var index of variable to be set
	 * @return 1 if all clauses are satisfied, -1 if one or more clauses are false,
	 *         and 0 otherwise
	 * @throws IllegalArgumentException if the precondition is not met
	 */
	public int unset(int var) {
		if (var < 1 || var > this.numberOfVariables) {
			throw new IllegalArgumentException(VARIABLE_MUST_BE_BETWEEN_1_AND_THE_NUMBER_OF_VARIABLES);
		}
		if (this.getValue(var) == 0) {
			throw new IllegalArgumentException("Value must be set before trying to unset.");
		}

		this.variableTruthValues[var - 1] = 0;
		return this.updateTruthValuesForUnset(var);
	}

	private int updateTruthValuesForUnset(int var) {
		for (int clause : this.variableMatrix[var - 1]) {
			int clauseState = 0;
			for (int variable : this.clausesMatrix[Math.abs(clause) - 1]) {
				int currentTruthValue = this.variableTruthValues[Math.abs(variable) - 1];
				if (currentTruthValue == 1 && variable > 0 || currentTruthValue == -1 && variable < 0) {
					clauseState = 1;
					break;
				} else if (currentTruthValue != 0) {
					clauseState = -1;
				}
			}
			if (this.clauseStates[Math.abs(clause) - 1] == 1 && clauseState != 1) {
				this.numberOfTrueClauses--;
			} else if (this.clauseStates[Math.abs(clause) - 1] == -1 && clauseState != -1) {
				this.numberOfFalseClauses--;
			}
			this.clauseStates[Math.abs(clause) - 1] = clauseState;
		}
		if (this.numberOfTrueClauses == this.numberOfClauses) {
			this.overallTruthValue = 1;
		} else if (this.numberOfTrueClauses + this.numberOfFalseClauses == this.numberOfClauses) {
			this.overallTruthValue = -1;
		} else {
			this.overallTruthValue = 0;
		}

		return this.overallTruthValue;
	}
}