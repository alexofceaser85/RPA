package edu.westga.cs3152.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

/**
 * File Reader for the CNF Matrix.
 * 
 * @author Alexander Ayers
 * @version Fall 2021
 *
 */
public class CNFFileReader {

	private int numberOfVariables;
	private int numberOfClauses;
	private int[][] clauseMatrix;
	private int parsedClauses;
	private int[][] variableMatrix;

	/**
	 * Default constructor
	 * 
	 * @precondition none
	 * @postcondition all default values have been set.
	 */
	public CNFFileReader() {
		this.clauseMatrix = null;
		this.numberOfClauses = 0;
		this.numberOfVariables = 0;
		this.parsedClauses = 0;
		this.variableMatrix = null;
	}
	
	/**
	 * Gets the number of variables.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the number of variables
	 */
	public int getNumberOfVariables() {
		return this.numberOfVariables;
	}

	/**
	 * Gets the number of clauses.
	 * 
	 * @precondition none
	 * @postconditino none
	 * @return the number of clauses
	 */
	public int getNumberOfClauses() {
		return this.numberOfClauses;
	}

	/**
	 * Gets the matrix of clauses.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the matrix of clauses.
	 */
	public int[][] getClauseMatrix() {
		return this.clauseMatrix;
	}
	
	/**
	 * Gets the variable matrix.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the variable matrix.
	 */
	public int[][] getVariableMatrix() {
		return this.variableMatrix;
	}

	/**
	 * Reads the specified file.
	 * 
	 * @precondition none
	 * @postcondition the matrix has been loaded with values.
	 * @param filename the name of the file
	 * @throws FileNotFoundException if filename doesn't match anything.
	 * @throws IllegalArgumentException if resulting matrices doesn't match any preconditions from CNF constructor.
	 */
	public void readFile(String filename) throws FileNotFoundException, IllegalArgumentException {
		File file = new File(filename);

		try (Scanner scanner = new Scanner(file)) {
			while (scanner.hasNextLine()) {
				String currentLine = scanner.nextLine();
				String[] currentInputs = currentLine.split(" ");

				if (this.isStartOfFile(currentInputs)) {
					this.initializeValuesForFields(currentInputs);

				} else if (this.clauseMatrix != null) {
					this.buildClauseMatrix(currentInputs);
					this.parsedClauses++;
				}
			}
			if (this.parsedClauses != this.numberOfClauses) {
				throw new IllegalArgumentException("File lines must not exceed number of clauses.");
			}

		} catch (FileNotFoundException ex) {
			throw new IllegalArgumentException(ex.getMessage());
		}
	}

	private void buildClauseMatrix(String[] currentInputs) {
		int[] values = new int[currentInputs.length - 1];
		int[] alreadyExistingValues = new int[this.numberOfVariables + 1];
		int valueIndex = 0;

		for (String current : currentInputs) {
			int currentValue = Integer.parseInt(current);
			int absoluteCurrentValue = Math.abs(currentValue);
			if (absoluteCurrentValue > this.numberOfVariables) {
				throw new IllegalArgumentException("Value within matrix cannot be greater than number of variables.");
			}
			if (alreadyExistingValues[absoluteCurrentValue] == -1) {
				throw new IllegalArgumentException("Clause cannot have repeated variables");
			}
			if (currentValue == 0) {
				break;
			} else {
				this.variableMatrix[absoluteCurrentValue - 1] = Arrays.copyOf(this.variableMatrix[absoluteCurrentValue - 1],
						this.variableMatrix[absoluteCurrentValue - 1].length + 1);
				this.variableMatrix[absoluteCurrentValue - 1][this.variableMatrix[absoluteCurrentValue - 1].length
						- 1] = (this.parsedClauses + 1) * Integer.signum(currentValue);
				values[valueIndex] = currentValue;
				alreadyExistingValues[absoluteCurrentValue] = -1;
				valueIndex++;
			}

		}
		this.clauseMatrix[this.parsedClauses] = values;
	}

	private boolean isStartOfFile(String[] splitLine) {
		return "p".equals(splitLine[0]) && "cnf".equals(splitLine[1]);
	}

	private void initializeValuesForFields(String[] splitLine) {
		this.numberOfVariables = Integer.parseInt(splitLine[2]);
		this.numberOfClauses = Integer.parseInt(splitLine[3]);
		this.clauseMatrix = new int[this.numberOfClauses][];
		this.variableMatrix = new int[this.numberOfVariables][0];
	}
}
